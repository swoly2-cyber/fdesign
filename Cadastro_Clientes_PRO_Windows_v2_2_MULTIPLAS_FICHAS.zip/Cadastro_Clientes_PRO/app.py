import os, re, sqlite3, threading, queue, shutil, sys
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

BASE = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'CadastroClientesPRO'
BASE.mkdir(parents=True, exist_ok=True)
DB = BASE / 'clientes.db'
FIELDS = [('pedido','Pedido'),('emissao','Emissão'),('cliente_empresa','Cliente/Empresa'),('nome','Nome'),('cortador','Cortador'),('endereco_corte','Endereço do corte'),('endereco','Endereço'),('cidade','Cidade'),('uf','UF'),('cep','CEP'),('telefone','Telefone'),('documento','CPF/CNPJ'),('produto','Produto'),('quantidade','Quantidade'),('unidade','Unidade'),('preco','Preço unitário'),('subtotal','Subtotal'),('observacoes','Observações')]

def database():
    con=sqlite3.connect(DB)
    con.execute('CREATE TABLE IF NOT EXISTS registros (id INTEGER PRIMARY KEY, pedido TEXT, emissao TEXT, codigo TEXT, nome TEXT, endereco TEXT, cidade TEXT, uf TEXT, cep TEXT, telefone TEXT, documento TEXT, produto TEXT, quantidade TEXT, unidade TEXT, preco TEXT, subtotal TEXT, observacoes TEXT, imagem TEXT, texto_ocr TEXT, criado_em TEXT)')
    # Migração não destrutiva de bancos de versões anteriores.
    existentes={r[1] for r in con.execute('PRAGMA table_info(registros)')}
    for coluna in ('cliente_empresa','cortador','endereco_corte'):
        if coluna not in existentes:
            con.execute(f"ALTER TABLE registros ADD COLUMN {coluna} TEXT DEFAULT ''")
    con.execute('CREATE INDEX IF NOT EXISTS ix_pedido ON registros(pedido)')
    con.execute('CREATE INDEX IF NOT EXISTS ix_nome ON registros(nome)')
    con.commit()
    return con

def clean(s): return re.sub(r'\s+',' ',s).strip(' :-;')
def grab(pattern, text, flags=re.I):
    m=re.search(pattern,text,flags)
    return clean(m.group(1)) if m else ''

def parse(text):
    t=text.replace('—','-').replace('–','-')
    d={k:'' for k,_ in FIELDS}
    d['pedido']=grab(r'PEDIDO\s*[:#]?\s*(\d{3,})',t)
    d['emissao']=grab(r'(?:EMISS[AÃ]O|DATA)\s*[:.]?\s*(\d{1,2}[/.]\d{1,2}[/.]\d{4})',t)
    # Cliente/Empresa é informado manualmente quando não consta explicitamente na nota.
    d['cliente_empresa']=grab(r'(?:CLIENTE\s*/\s*EMPRESA|EMPRESA)\s*:\s*([^\n]+)',t)
    d['cortador']=grab(r'\bCORTADOR\s*:\s*([^\n]+)',t)
    d['endereco_corte']=grab(r'ENDERE[CÇ]O\s+DO\s+CORTE\s*:\s*([^\n]+)',t)
    d['nome']=grab(r'\bNOME\s*:\s*([^\n]+)',t)
    d['endereco']=grab(r'\bENDERE[CÇ]O\s*:\s*(.+?)(?=\s+CIDADE\s*:|\s+UF\s*:|\n|$)',t)
    d['cidade']=grab(r'\bCIDADE\s*:\s*(.+?)(?=\s+UF\s*:|\s+CEP\s*:|\n|$)',t)
    d['uf']=grab(r'\bUF\s*:\s*([A-Z]{2})',t)
    d['cep']=grab(r'\bCEP\s*:\s*([\d.\-]{8,10})',t)
    d['telefone']=grab(r'\b(?:FONE|TELEFONE|CELULAR)\s*:\s*([\d ()\-]{8,20})',t)
    d['documento']=grab(r'\b(?:CNPJ|CPF)\s*:\s*([\d.\-/]{11,20})',t)
    # Nota: os dados de produto são heurísticos; sempre verificáveis na interface.
    lines=[clean(x) for x in t.splitlines() if clean(x)]
    for i,line in enumerate(lines):
        if re.search(r'TACTEL|SPANDEX|POLIESTER|ELASTANO|TECIDO',line,re.I):
            d['produto']=line[:180]
            if i+1<len(lines) and re.search(r'ELASTANO|POLIESTER',lines[i+1],re.I): d['produto']+=' '+lines[i+1][:80]
            break
    # Busca quantidade e valores na mesma linha, próximos a unidade MT/M/KG
    for line in lines:
        m=re.search(r'(?<!\d)(\d{1,6}[,.]\d{3})\s*(MT|KG|M)\b\s+([\d.,]+)\s+([\d.,]+)',line,re.I)
        if m:
            d['quantidade'],d['unidade'],d['preco'],d['subtotal']=m.groups(); break
    return d

def recognize(path):
    try:
        import pytesseract
        from PIL import Image, ImageOps, ImageEnhance, ImageFilter
    except ImportError:
        raise RuntimeError('Bibliotecas ausentes. Execute INSTALAR.bat antes de usar.')
    possible=[r'C:\Program Files\Tesseract-OCR\tesseract.exe',r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe']
    if not shutil.which('tesseract'):
        for p in possible:
            if Path(p).exists(): pytesseract.pytesseract.tesseract_cmd=p;break
        else: raise RuntimeError('Tesseract OCR não encontrado. Instale-o conforme LEIA-ME.txt.')
    im=Image.open(path); im=ImageOps.exif_transpose(im).convert('RGB')
    if max(im.size)<2200: im=im.resize((int(im.width*2200/max(im.size)),int(im.height*2200/max(im.size))))
    gray=ImageOps.grayscale(im)
    gray=ImageEnhance.Contrast(gray).enhance(1.6)
    variants=[im,gray]
    texts=[]
    for variant in variants:
        try: texts.append(pytesseract.image_to_string(variant,lang='por+eng',config='--psm 6'))
        except pytesseract.TesseractError:
            texts.append(pytesseract.image_to_string(variant,lang='eng',config='--psm 6'))
    a,b=texts
    return a if len(re.findall(r'\b(?:PEDIDO|NOME|ENDERECO|CIDADE|CNPJ)\b',a,re.I))>=len(re.findall(r'\b(?:PEDIDO|NOME|ENDERECO|CIDADE|CNPJ)\b',b,re.I)) else b

class App:
    def __init__(self,root):
        self.root=root;root.title('Cadastro de Clientes PRO | Leitura de Notas');root.geometry('1150x780');root.minsize(900,620)
        self.q=queue.Queue();self.batch_active=False;self.batch_total=0;self.batch_done=0;self.batch_saved=0;self.batch_skipped=0;self.path=None;self.current_id=None;self.ocr='';self.vars={k:tk.StringVar() for k,_ in FIELDS};self.status=tk.StringVar(value='Pronto para selecionar uma nota.')
        self.con=database();self.build();self.refresh();root.after(150,self.poll)
    def build(self):
        style=ttk.Style();style.theme_use('clam');style.configure('TButton',padding=7);style.configure('Title.TLabel',font=('Segoe UI',17,'bold'),foreground='#123e72');style.configure('TLabel',font=('Segoe UI',10));style.configure('TEntry',padding=4)
        top=ttk.Frame(self.root,padding=12);top.pack(fill='x')
        ttk.Label(top,text='CADASTRO DE CLIENTES PRO',style='Title.TLabel').pack(side='left')
        ttk.Button(top,text='Selecionar várias fichas',command=self.choose_many).pack(side='right',padx=4)
        ttk.Button(top,text='Selecionar foto / PDF',command=self.choose).pack(side='right',padx=4)
        ttk.Button(top,text='Salvar alterações',command=self.save).pack(side='right',padx=4)
        ttk.Button(top,text='Novo cadastro',command=self.clear).pack(side='right',padx=4)
        pane=ttk.Panedwindow(self.root,orient='horizontal');pane.pack(fill='both',expand=True,padx=12,pady=5)
        left=ttk.Frame(pane);right=ttk.Frame(pane);pane.add(left,weight=3);pane.add(right,weight=2)
        canvas=tk.Canvas(left,highlightthickness=0);sb=ttk.Scrollbar(left,orient='vertical',command=canvas.yview);frame=ttk.Frame(canvas,padding=8)
        frame.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.create_window((0,0),window=frame,anchor='nw');canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side='left',fill='both',expand=True);sb.pack(side='right',fill='y')
        for idx,(key,label) in enumerate(FIELDS):
            ttk.Label(frame,text=label).grid(row=idx,column=0,sticky='w',padx=5,pady=6)
            ttk.Entry(frame,textvariable=self.vars[key],width=51).grid(row=idx,column=1,sticky='ew',padx=5,pady=6)
        frame.columnconfigure(1,weight=1)
        ttk.Label(right,text='Foto original / pré-visualização',font=('Segoe UI',11,'bold')).pack(anchor='w')
        self.preview=ttk.Label(right,text='Nenhuma imagem selecionada',anchor='center');self.preview.pack(fill='both',expand=True,pady=8)
        ttk.Label(right,text='Texto reconhecido (para conferência)').pack(anchor='w')
        self.raw=tk.Text(right,height=10,wrap='word',font=('Consolas',9));self.raw.pack(fill='both',expand=True)
        bottom=ttk.Frame(self.root,padding=(12,5));bottom.pack(fill='both',expand=False)
        ttk.Label(bottom,text='Pesquisar por nome, empresa, cortador ou pedido:').pack(side='left')
        self.search=tk.StringVar();e=ttk.Entry(bottom,textvariable=self.search,width=35);e.pack(side='left',padx=8);e.bind('<KeyRelease>',lambda ev:self.refresh())
        ttk.Button(bottom,text='Exportar CSV',command=self.export).pack(side='right')
        self.tree=ttk.Treeview(self.root,columns=('id','pedido','nome','cliente_empresa','cortador','emissao','subtotal'),show='headings',height=7)
        for col,w in [('id',50),('pedido',100),('nome',330),('cliente_empresa',170),('cortador',130),('emissao',120),('subtotal',120)]:self.tree.heading(col,text=col.title());self.tree.column(col,width=w)
        self.tree.pack(fill='both',expand=False,padx=12,pady=4);self.tree.bind('<<TreeviewSelect>>',self.load_selected)
        ttk.Label(self.root,textvariable=self.status,relief='sunken',padding=5).pack(fill='x')
    def choose(self):
        if self.batch_active:
            messagebox.showinfo('Processamento','Aguarde o lote atual terminar.');return
        p=filedialog.askopenfilename(filetypes=[('Fotos e PDF','*.jpg *.jpeg *.png *.tif *.tiff *.bmp *.pdf')]);
        if not p:return
        self.path=p;self.current_id=None;self.show_preview(p);self.status.set('Lendo nota... aguarde.');threading.Thread(target=self.worker,args=(p,),daemon=True).start()
    def choose_many(self):
        if self.batch_active:
            messagebox.showinfo('Processamento','Aguarde o lote atual terminar.')
            return
        paths=filedialog.askopenfilenames(title='Selecione as fichas',filetypes=[('Fotos e PDF','*.jpg *.jpeg *.png *.tif *.tiff *.bmp *.pdf')])
        if not paths:return
        self.batch_active=True;self.batch_total=len(paths);self.batch_done=0;self.batch_saved=0;self.batch_skipped=0
        self.status.set(f'Lendo lote: 0/{self.batch_total} fichas...')
        threading.Thread(target=self.batch_worker,args=(list(paths),),daemon=True).start()

    def batch_worker(self,paths):
        for p in paths:
            try:
                ocr=self.read_ocr(p)
                self.q.put(('batch_item',p,ocr,parse(ocr)))
            except Exception as ex:
                self.q.put(('batch_error',p,str(ex)))
        self.q.put(('batch_finished',))

    def read_ocr(self,p):
        if p.lower().endswith('.pdf'):
            try:
                import fitz
                import tempfile
                with fitz.open(p) as doc:
                    if not len(doc):raise RuntimeError('PDF vazio')
                    pix=doc[0].get_pixmap(matrix=fitz.Matrix(2,2))
                    with tempfile.NamedTemporaryFile(suffix='.png',delete=False) as tmp:
                        tmp_path=tmp.name
                    try:
                        pix.save(tmp_path)
                        return recognize(tmp_path)
                    finally:
                        try:os.unlink(tmp_path)
                        except OSError:pass
            except ImportError:raise RuntimeError('Instale as dependências de PDF com INSTALAR.bat')
        return recognize(p)

    def save_batch_item(self,p,ocr,data):
        if not data['nome'] and not data['pedido']:
            return False
        if data['pedido'] and self.con.execute('SELECT 1 FROM registros WHERE pedido=? LIMIT 1',(data['pedido'],)).fetchone():
            return False
        cols=[k for k,_ in FIELDS]
        vals=[data.get(k,'') for k in cols]
        self.con.execute('INSERT INTO registros ('+','.join(cols)+',imagem,texto_ocr,criado_em) VALUES ('+','.join('?' for _ in range(len(cols)+3))+')',vals+[p,ocr,datetime.now().isoformat(timespec='seconds')])
        self.con.commit()
        return True

    def worker(self,p):
        try:
            ocr=self.read_ocr(p)
            self.q.put(('done',p,ocr,parse(ocr)))
        except Exception as ex:self.q.put(('error',str(ex)))
    def poll(self):
        try:
            while True:
                event=self.q.get_nowait()
                if event[0]=='batch_item':
                    _,p,ocr,data=event
                    try:
                        if self.save_batch_item(p,ocr,data):self.batch_saved+=1
                        else:self.batch_skipped+=1
                    except Exception:self.batch_skipped+=1
                    self.batch_done+=1
                    self.status.set(f'Lote: {self.batch_done}/{self.batch_total} | Salvas: {self.batch_saved} | Não cadastradas/duplicadas: {self.batch_skipped}')
                elif event[0]=='batch_error':
                    self.batch_done+=1;self.batch_skipped+=1
                    self.status.set(f'Lote: {self.batch_done}/{self.batch_total} | Erro ao ler {Path(event[1]).name}: {event[2]}')
                elif event[0]=='batch_finished':
                    self.batch_active=False;self.refresh()
                    self.status.set(f'Lote concluído: {self.batch_saved} salvas; {self.batch_skipped} não cadastradas/duplicadas. Confira os dados.')
                    messagebox.showinfo('Lote concluído',f'Fichas selecionadas: {self.batch_total}\nCadastradas: {self.batch_saved}\nNão cadastradas/duplicadas: {self.batch_skipped}\n\nConfira os dados reconhecidos.')
                elif event[0]=='error':self.status.set('Falha na leitura.');messagebox.showerror('Erro OCR',event[1])
                elif event[0]=='done':
                    _,p,ocr,data=event
                    if p!=self.path:continue
                    self.ocr=ocr;self.raw.delete('1.0','end');self.raw.insert('1.0',ocr)
                    for k in self.vars:self.vars[k].set(data.get(k,''))
                    if not data['nome'] and not data['pedido']:
                        self.status.set('Não foi possível identificar nome ou pedido. Confira o texto e preencha antes de salvar.');continue
                    self.auto_save()
        except queue.Empty:pass
        self.root.after(150,self.poll)
    def auto_save(self):
        try:self.save(auto=True)
        except Exception as e:messagebox.showerror('Erro ao salvar',str(e))
    def save(self,auto=False):
        d={k:v.get().strip() for k,v in self.vars.items()}
        if not d['nome'] and not d['pedido']:
            if not auto:messagebox.showwarning('Cadastro incompleto','Informe pelo menos o nome ou o número do pedido.')
            return
        # Evita duplicação de pedidos; pedido é a chave da nota, não do cliente.
        existing=None
        if d['pedido']:existing=self.con.execute('SELECT id FROM registros WHERE pedido=? ORDER BY id DESC LIMIT 1',(d['pedido'],)).fetchone()
        if self.current_id:existing=(self.current_id,)
        cols=[k for k,_ in FIELDS]
        vals=[d[k] for k in cols]
        if existing:
            rid=existing[0]
            if auto:
                self.current_id=rid;self.status.set(f'Pedido {d["pedido"]} já cadastrado. Registro existente preservado; confira antes de alterar.');return
            self.con.execute('UPDATE registros SET '+','.join(k+'=?' for k in cols)+',imagem=?,texto_ocr=? WHERE id=?',vals+[self.path or '',self.raw.get('1.0','end').strip(),rid]);self.current_id=rid
        else:
            cur=self.con.execute('INSERT INTO registros ('+','.join(cols)+',imagem,texto_ocr,criado_em) VALUES ('+','.join('?' for _ in range(len(cols)+3))+')',vals+[self.path or '',self.raw.get('1.0','end').strip(),datetime.now().isoformat(timespec='seconds')]);self.current_id=cur.lastrowid
        self.con.commit();self.refresh();self.status.set('Cadastro salvo automaticamente. Confira os campos reconhecidos.' if auto else 'Cadastro atualizado com sucesso.')
    def clear(self):
        self.current_id=None;self.path=None;self.ocr=''
        for v in self.vars.values():v.set('')
        self.raw.delete('1.0','end');self.preview.configure(image='',text='Nenhuma imagem selecionada');self.preview.image=None
    def refresh(self):
        for item in self.tree.get_children():self.tree.delete(item)
        s='%'+self.search.get().strip()+'%'
        for r in self.con.execute('SELECT id,pedido,nome,cliente_empresa,cortador,emissao,subtotal FROM registros WHERE nome LIKE ? OR pedido LIKE ? OR cliente_empresa LIKE ? OR cortador LIKE ? ORDER BY id DESC LIMIT 500',(s,s,s,s)):
            self.tree.insert('', 'end',values=r)
    def load_selected(self,event=None):
        selected=self.tree.selection()
        if not selected:return
        rid=self.tree.item(selected[0],'values')[0]
        cols=[k for k,_ in FIELDS]
        row=self.con.execute('SELECT '+','.join(cols)+',imagem,texto_ocr FROM registros WHERE id=?',(rid,)).fetchone()
        if not row:return
        self.current_id=int(rid)
        for k,v in zip(cols,row[:len(cols)]):self.vars[k].set(v or '')
        self.path=row[-2];self.raw.delete('1.0','end');self.raw.insert('1.0',row[-1] or '');self.show_preview(self.path)
    def show_preview(self,p):
        try:
            from PIL import Image,ImageTk,ImageOps
            if p and Path(p).exists() and not p.lower().endswith('.pdf'):
                im=ImageOps.exif_transpose(Image.open(p));im.thumbnail((430,300));photo=ImageTk.PhotoImage(im);self.preview.configure(image=photo,text='');self.preview.image=photo;return
        except Exception:pass
        self.preview.configure(image='',text='PDF selecionado' if p and p.lower().endswith('.pdf') else 'Foto original indisponível');self.preview.image=None
    def export(self):
        import csv
        p=filedialog.asksaveasfilename(defaultextension='.csv',initialfile='cadastros.csv',filetypes=[('CSV Excel','*.csv')]);
        if not p:return
        cols=[k for k,_ in FIELDS]
        with open(p,'w',encoding='utf-8-sig',newline='') as f:
            writer=csv.writer(f,delimiter=';');writer.writerow([label for _,label in FIELDS]);writer.writerows(self.con.execute('SELECT '+','.join(cols)+' FROM registros ORDER BY id DESC'))
        messagebox.showinfo('Exportação','Arquivo CSV gerado com sucesso.')

if __name__=='__main__':
    root=tk.Tk();App(root);root.mainloop()
