@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt pyinstaller
py -m PyInstaller --noconfirm --onefile --windowed --name Cadastro_Clientes_PRO app.py
if errorlevel 1 pause
